"""
torchjpeg
====================================
torchjpeg provides an API for accessing low-level JPEG related constructs directly from pytorch.
"""
